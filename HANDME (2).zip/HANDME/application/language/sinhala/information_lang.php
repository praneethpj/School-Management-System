<?php

$lang['welcome'] = 'ආයුබෝවන්';;
$lang['Name'] = 'නම';
$lang['School']='පාසල';
$lang['NewSchools']='නව පාසල';
$lang['Schoolname']='පාසලේ නම';
$lang['Schooldesc']='පාසලේ විස්තර';
$lang['Add']='ඇතුළත් කරන්න ';
$lang['Updateschools']='යාවත්කාලීන කරන්න';
$lang['Update']='යාවත්කාලීන';

$lang['Grade']='ශ්‍රේණිය';
$lang['Newgrade']='අලුත් ශ්‍රේණියක්';;
$lang['Gradename']='ශ්‍රේණියේ නම';
$lang['Gradedesc']='ශ්‍රේණියේ විස්තර';;

$lang['Student']='ශිෂ්‍යයා';
$lang['Newstudent']='අලුත් ශිෂ්‍යයෙක්';
$lang['Firstname']='පළමු නම';
$lang['Lastname']='අවසන් නම';
$lang['Birthday']='උපන්දිනය';
$lang['Addressline1']='ලිපිනය';
$lang['Addressline2']='ලිපිනය';

$lang['Subject']='විෂය';
$lang['Newsubject']='අලුත්  විෂයයක්';
$lang['Subjectname']='විෂයේ නම';
$lang['Subjectdesc']='විෂයේ විස්තර';;
 
 
