<?php

$lang['welcome'] = 'Welcome';
$lang['Name'] = 'Name';
$lang['School']='School';
$lang['NewSchools']='New Schools';
$lang['Schoolname']='School name';
$lang['Schooldesc']='School Description';
$lang['Add']='Add';
$lang['Updateschools']='Update Schools';
$lang['Update']='Update';

$lang['Grade']='Hall';
$lang['Newgrade']='New Hall';
$lang['Gradename']='Hall Name';
$lang['Gradedesc']='Hall Desc';

$lang['Student']='Student';
$lang['Newstudent']='New Student';
$lang['Firstname']='First Name';
$lang['Lastname']='Last Name';
$lang['Birthday']='Birth Day';
$lang['Addressline1']='First Address Line';
$lang['Addressline2']='Second Address Line';

$lang['Subject']='Subject';
$lang['Newsubject']='New Subject';
$lang['Subjectname']='Subject Name';
$lang['Subjectdesc']='Subject Description';
 
//////////////////////////////////////////////////////////////////////////////

$lang['Rating']='Rating';
$lang['Comment']='Comment';
 
 
